<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP PetitionsController
 * @author bruno
 */
class PetitionsController extends AppController {

    public function index() {

    }

    public function classes() {

        $doc = new DOMDocument();

        $doc->loadHTML(file_get_contents('../View/Petitions/index.ctp'));

        debug($doc);
    }

    public function read_files() {

        //$this->layout = 'ajax';

        $this->loadModel('PetitionClass');
        $classes = $this->PetitionClass->find('all', array(
            'conditions' => array('PetitionClass.name_ancii LIKE' => '% %'),
            'order' => array('CHAR_LENGTH(PetitionClass.name_ancii)' => 'DESC')
        ));

        /* foreach ($classes as $class) {
          unset($class['PetitionClass']['id']);
          $json[] = $class['PetitionClass'];
          }

          $this->set('json', json_encode($json));
         */
        App::uses('Folder', 'Utility');
        App::uses('File', 'Utility');

        $dir = new Folder('../files');

        $files = $dir->find('08.*\.txt');

        foreach ($files as $key => $file) {
            $file = new File($dir->pwd() . DS . $file);
            $contents = $file->read();

            //debug($file);
            //debug($contents);

            $grande = array();
            $normal = array();

            foreach ($classes as $class) {

                //$clear_class = preg_replace('#[^1-9a-z]#i', '', $class['PetitionClass']['name']);
                $clear_contents = preg_replace(array('/[ ]{2,}/', '/[^A-Za-z0-9\- ]/'), array(' ', ''), iconv("UTF-8", "ASCII//TRANSLIT//IGNORE", $contents));

                //debug(preg_quote($class['PetitionClass']['name']));
                if (preg_match("#" . strtoupper($class['PetitionClass']['name_ancii']) . "#", $clear_contents)) {
                    $grande[] = $class['PetitionClass']['code'];
                } elseif (preg_match("#" . $class['PetitionClass']['name_ancii'] . "#i", $clear_contents)) {
                    $normal[] = $class['PetitionClass']['code'];
                }
            }

            $petition = array(
                'process' => str_replace('.txt', '', $file->name)
            );

            if (count($grande)) {
                $petition['class'] = implode(',', array_unique($grande));
            } elseif (count($normal)) {
                $petition['class'] = implode(',', array_unique($normal));
            }

            //debug($petition);

            $this->Petition->create();
            $this->Petition->save($petition);

            //if ($key >= 50) {
            //    break;
            //}
            // $file->write('I am overwriting the contents of this file');
            // $file->append('I am adding to the bottom of this file.');
            // $file->delete(); // I am deleting this file
            $file->close(); // Be sure to close the file when you're done
        }
    }

}
