<?php

class DATABASE_CONFIG {

    public $default = array(
        'datasource' => 'Database/Mysql',
        'persistent' => false,
        'host' => 'localhost',
        'login' => 'hackathon',
        'password' => 'hackathon',
        'database' => 'hackathon',
        'prefix' => '',
        'encoding' => 'utf8'
    );

}
