<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP PetitionClassesController
 * @author bruno
 */
class PetitionClassesController extends AppController {

    public function index() {
        $classes = $this->PetitionClass->find('all');

        foreach ($classes as $class) {
            $class['PetitionClass']['name_ancii'] = preg_replace(array('/[ ]{2,}/', '/[^A-Za-z0-9\- ]/'), array(' ', ''), iconv("UTF-8", "ASCII//TRANSLIT//IGNORE", $class['PetitionClass']['name']));
            $this->PetitionClass->save($class);
        }
    }

}
